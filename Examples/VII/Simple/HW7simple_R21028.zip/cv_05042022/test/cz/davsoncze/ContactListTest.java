package cz.davsoncze;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactListTest {
    @Test
    public void findContactByEmailAndReturnNull(){

    }
    @Test
    public void findContactByEmailWithThisEmail(){

    }

}