package cz.davson.files;

import java.util.Map;
import java.util.TreeMap;

public class Test {

    //Map<String,Integer> mp=new TreeMap<>();

    /*for (int i = 0; i < arrayOfWords.length; i++) {
        if(mp.containsKey(arrayOfWords[i]))
        {
            mp.put(arrayOfWords[i], mp.get(arrayOfWords[i])+1);
        }
        else
        {
            mp.put(arrayOfWords[i],1);
        }

        for(Map.Entry<String,Integer> entry: mp.entrySet())
        {
            mp.entrySet()
                    .stream()
                    .sorted(Map.Entry.comparingByValue())
                    .forEach( e -> {
                        System.out.println(e.getKey()+ " - "+e.getValue());

                    });
        }

        for(Map.Entry<String,Integer> entry: mp.entrySet())
        {
            mp.entrySet()
                    .stream()
                    .sorted(Map.Entry.comparingByValue())
                    .forEach( e -> {
                        System.out.println(e.getKey()+ " - "+e.getValue());

                    });
            //}(entry.getKey()+ " - "+entry.getValue());)*/

    /*
                    for (int i = 0; i < arrayOfWords.length; i++) {
                    if (mp.containsValue(arrayOfWords[i])) {
                        mp.put(arrayOfWords[i], mp.get(arrayOfWords[i]) + 1);
                    } else {
                        mp.put(arrayOfWords[i], 1);
                    }
                }
            }

            for (Map.Entry<String, Integer> entry : mp.entrySet()) {
                mp.entrySet()
                        .stream()
                        .sorted(Map.Entry.comparingByValue())
                        .forEach(e -> {
                            System.out.println(e.getKey() + " - " + e.getValue());

                        });
            }
     */
}
