import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        String str;

        System.out.println("Enter your input directory: ");
        str = scanner.nextLine();
        Path inPath = Paths.get(str);
        File inDir = new File(inPath.toString());

        System.out.println("Enter your output directory: ");
        str = scanner.nextLine();
        Path pathOUT = Paths.get(str);
        File outDir = new File(pathOUT.toString());

        Operation.copy(inDir, outDir);
        System.out.println("Copy was successful.");
    }
}