package cz.davsoncze;

public class NullArgumentException extends Throwable {
    public NullArgumentException(String message) {
        super(message);
    }
}
