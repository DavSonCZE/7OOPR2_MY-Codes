package com.davsoncze;

public enum PersonType {
    STUDENT, EMPLOYEE;
}
