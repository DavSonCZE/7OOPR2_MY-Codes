package cz.davsoncze;

public class Main {
    public static void main(String[] args) throws Exception {

        FileOperation.readFile(args[0],args[1]);

    }
}
